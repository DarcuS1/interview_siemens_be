package site.samijosan.siemenshotels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiemensHotelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
